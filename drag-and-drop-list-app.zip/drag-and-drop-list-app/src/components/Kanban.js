import React, { useCallback, useState } from 'react';
import './Kanban.css'; 
import cardsData from '../data/cards.json';
import KanbanCard from './KanbanCard';
import { ItemTypes } from './ItemTypes';
import { useDrop } from 'react-dnd';
import { Move } from './KanbanController'

export default function Kanban({x, y}){
 {/*
    const [lists, setLists] = useState(()=>{
        return data.Lists;
    });
    */}

    const [cards, setCards] = useState(cardsData);

    const [{isOver}, drop] = useDrop(
        () => ({
          accept: ItemTypes.CARD,
          drop: () => Move(x, y),
          collect: monitor => ({
            isOver: !!monitor.isOver(),
          }),
        })
      )


    const renderCard = useCallback((card, index) => {
        return (
            //How to pass a card okect?
          <KanbanCard 
            id={card.id} 
            title={card.title} 
            author={card.author}
            date={card.date}
            uri={card.uri}
            desc={card.desc}
            index={index}
          />
        )
      }, [])

    return (
        <div className="KanbanContainer">
            <b>List 1</b>
            <div
                ref={drop}
                style={{
                    position: 'relative',
                    width: '100%',
                    height: '100%',
                }}
            >
          {cards.map((card, i) => renderCard(card, i))}
          </div>
        </div>
      )

}

