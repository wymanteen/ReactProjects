
import React from 'react';

export default function KanbanList(){


    return (
        <div>
            <h1>Kanban List</h1>
        </div>
      )

}

