import React, { useCallback, useState } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { ItemTypes } from './ItemTypes.js';
import Card from './Card.js';
import update from 'immutability-helper';
import cardsData from '../data/cards.json';

function getStyle(backgroundColor) {
    return {
      border: '1px solid rgba(0,0,0,0.2)',
      minHeight: '8rem',
      minWidth: '8rem',
      backgroundColor,
      padding: '1rem',
      paddingTop: '1rem',
      margin: '1rem',
      textAlign: 'center',
      float: 'left',
      fontSize: '1rem',
    }
  }


export default function KanbanList({ list }){

    const [cards, setCards] = useState(cardsData);

    const [hasDropped, setHasDropped] = useState(false)
    const [hasDroppedOnChild, setHasDroppedOnChild] = useState(false)
    const [{ isOver, isOverCurrent }, drop] = useDrop(
      () => ({
        accept: ItemTypes.CARD,
        drop(_item, monitor) {
          const didDrop = monitor.didDrop()
          if (didDrop) {
            return
          }
          setHasDropped(true)
          setHasDroppedOnChild(didDrop)
        },
        collect: (monitor) => ({
          isOver: monitor.isOver(),
          isOverCurrent: monitor.isOver({ shallow: true }),
        }),
      }),
      [setHasDropped, setHasDroppedOnChild],
    )

    let backgroundColor = 'lightgrey'
    /*
    if (isOverCurrent || (isOver)) {
      backgroundColor = 'grey'
    }
    */

    const renderCards = useCallback((cards) => {
        //cards && console.log(cards);

        //var html = cards.map((card, i)=><Book id={card.id} title={card.title} author={card.author} date={card.date} uri={card.uri} desc={card.desc}/>)
        var html = cards.map((card, i)=> <Card
                                            key={card.id}
                                            index={i}
                                            id={card.id}
                                            author={card.author}
                                            date={card.date}
                                            title={card.title}
                                            uri={card.uri}
                                            moveCard={moveCard}
                                        />);

        return (cards && <>{html}</>)
    }, []);

    const moveCard = useCallback((dragIndex, hoverIndex) => {
        setCards((prevCards) =>
          update(prevCards, {
            $splice: [
              [dragIndex, 1],
              [hoverIndex, 0, prevCards[dragIndex]],
            ],
          }),
        )
      }, []);


    return (
      <div ref={drop} style={getStyle(backgroundColor)}>
        {list.listName}
        <br />
        {hasDropped && <span> {hasDroppedOnChild && ' on child'}</span>}
  
        {renderCards(cards.filter(x => x.status == list.id))};
        
      </div>
    )
  }

