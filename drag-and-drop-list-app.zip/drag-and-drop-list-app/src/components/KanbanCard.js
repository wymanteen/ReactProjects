
import React, { useRef } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import { ItemTypes } from './ItemTypes';
import './KanbanCard.css'; 
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import MoreVertIcon from '@mui/icons-material/MoreVert';


export default function KanbanCard({id, title, author, date, uri, desc, index}){

    const [{isDragging}, drag] = useDrag(() => ({
        type: ItemTypes.CARD,
        collect: monitor => ({
          isDragging: !!monitor.isDragging(),
        }),
      }))

    return (
        <div className='KanbanCardContainer'>
            <div ref={drag}
            style={{
                opacity: isDragging ? 0.5 : 1,
                fontSize: 25,
                fontWeight: 'bold',
                cursor: 'move',
            }}>
                <Card sx={{ maxWidth: 345 }} key={id}>
                    <CardHeader
                        action={
                            <IconButton aria-label="settings">
                            <MoreVertIcon />
                            </IconButton>
                        }
                        title={`${title} - ${author}`}
                        subheader={date}
                        />
                        <CardMedia
                        component="img"
                        height="194"
                        image={uri}
                        alt={title}
                    />
                    {/*
                    <CardContent>
                    <Typography variant="body2" color="text.secondary">
                        {desc}
                    </Typography>
                    </CardContent>
                    */}
                    <CardActions disableSpacing>
                    </CardActions>
                </Card>
            </div>
        </div>
      )

}

